export default function About() {
  return (
    <div className="container mt-5">
      <h1>Welcome to About Page</h1>
     
    </div>
  );
}