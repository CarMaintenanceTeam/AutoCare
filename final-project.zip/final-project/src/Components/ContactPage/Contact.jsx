export default function Contact() {
  return (
    <div className="container mt-5">
      <h1>Welcome to Contact Page</h1>
     
    </div>
  );
}