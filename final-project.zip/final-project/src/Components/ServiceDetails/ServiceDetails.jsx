export default function ServiceDetails() {
  return (
    <div className="container mt-5">
      <h1>Welcome to Services Page</h1>
     
    </div>
  );
}